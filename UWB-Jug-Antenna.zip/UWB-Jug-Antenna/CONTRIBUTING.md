# Contributing Guidelines

Thank you for your interest in contributing to this project!

## How to Contribute

1. Fork this repository.
2. Clone your fork: `git clone https://github.com/yourusername/UWB-Jug-Antenna.git`
3. Create a new branch: `git checkout -b feature/your-feature-name`
4. Commit your changes and push: `git push origin feature/your-feature-name`
5. Create a Pull Request.

## Code of Conduct

Please be respectful and professional in your interactions.

## Suggestions

- Include test results for any improvements
- Provide simulation files for design contributions
