# 📡 Miniaturized Jug-Shaped CPW-Fed UWB Antenna for Wireless Communication

This repository contains the design, simulation, and evaluation of a compact coplanar waveguide (CPW)-fed Ultra-Wideband (UWB) Jug-Shaped Antenna developed for wireless applications such as 5G, Wi-Fi, radar systems, and satellite communication.

## 🧠 Abstract

This project presents the design of a miniaturized jug-shaped antenna with CPW feed for UWB applications, showing excellent impedance matching across three bands:  
- **2.6383–3.6896 GHz**
- **4.6596–5.0724 GHz**
- **6.5805–9.4254 GHz**

The antenna exhibits return loss < -10 dB, high radiation efficiency, and gain suitable for various multi-band applications like Wi-Fi, 5G, C/X-band satellite communication, and radar.

## 🏗️ System Overview

### Hardware:
- **Substrate**: FR4 (εr = 4.4, thickness = 1.6mm)
- **Design**: Jug-shaped radiator with CPW feed
- **Tools**: Vector Network Analyzer, ANACOVA chamber for testing

### Software:
- **CST Studio Suite 2019**: Electromagnetic simulation
- **Post-processing**: MATLAB / Python for plotting S11, VSWR, gain, etc.

## 📈 Key Results

| Metric                  | Value                         |
|-------------------------|-------------------------------|
| Return Loss             | < -10 dB across UWB range     |
| Gain                    | Up to 2.5 dB                  |
| Radiation Efficiency    | > 90% in UWB band             |
| Total Efficiency        | Peak around 3–6 GHz           |
| Substrate               | FR4                           |

## 📂 Directory Structure

- `docs/` – Project report and visualizations
- `simulation/` – CST files and simulation plots
- `hardware/` – PCB layout and fabrication files
- `test/` – Measurement setup and raw VNA data

## 📚 Citation

If you use this work, please cite using the provided `CITATION.cff` or:

> Rajappa H S, *Miniaturized Jug-Shaped CPW-Fed UWB Antenna for Wireless Communication*, AIT Chikkamagaluru, 2024.

## 🛠️ Contributing

We welcome suggestions and improvements. Please see [`CONTRIBUTING.md`](CONTRIBUTING.md) for details.

## 📝 License

This project is licensed under the MIT License. See the [`LICENSE`](LICENSE) file for details.
